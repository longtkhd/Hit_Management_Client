var __wpo = {
  "assets": {
    "main": [
      "/d49c034ff7942ecaabdb3020525b1f7e.jpg",
      "/0380f1c2dad138349aaf3999ed7ebbc3.png",
      "/5db5824b5b19760318f568bf51b054a2.png",
      "/b8e69b9285376214817341b0c7865f37.png",
      "/aab95c6bfbf97c9b5cd5ab91379ef07d.png",
      "/c5f5465af89bb5c4ada576b288e59c05.png",
      "/f278b26b6db2854fc4b867cb5bcba050.png",
      "/6ea9aa82fc3835131596509fac77bf5a.png",
      "/8dec7022ea74eaad8e1fb0b658dd3047.png",
      "/d4764421c2270359a4a9de16fbd18111.png",
      "/498dc89b7cccac1624b35953d72fc099.png",
      "/08690ee3a5e27172f13fb2d32c180717.png",
      "/ed23534bf8393d1400c4bf4d76308230.jpg",
      "/ffdc6dc5c7d052bf229b384662d6d76f.png",
      "/b7b3ecb64b6cf9f7a068fd6fd6b6f8af.png",
      "/73564913de6236214a0d1e4f32c1bd26.jpg",
      "/favicon.ico",
      "/1c37d17ab4763e2f9c9d9f76f856fa4f.png",
      "/9d03f51123413552f6296791f90afe73.png",
      "/2146d266234f33e71c8ad2b007942695.png",
      "/9ac0ec2f24f760d5796b3bac2c2f1f59.png",
      "/36d69487d539f38cd97f2d457adf608a.png",
      "/9e856521ccb74baf3a729aba9a1d8083.jpg",
      "/759e7c3789dc1116b4e2eb9154be3f1d.png",
      "/runtime.c6c2340d0ffa88711909.js",
      "/"
    ],
    "additional": [
      "/npm.webpack.74f5a4a58a24174e8f47.chunk.js",
      "/npm.lodash.f669a47301d5f23fffaf.chunk.js",
      "/npm.material-ui.718fddd6d6126902d007.chunk.js",
      "/npm.redux-saga.ba4aadbebb4d4d4e9349.chunk.js",
      "/npm.intl.b21cb7bc6c0cd0d196b0.chunk.js",
      "/main.5287e0059022fafb53d0.chunk.js",
      "/npm.axios.0282152507966a1f7a82.chunk.js",
      "/npm.babel.78a7a1d12b1efa6b4ca1.chunk.js",
      "/npm.connected-react-router.935dd82e1f14cac812d7.chunk.js",
      "/npm.css-vendor.8e939cc2ba9b8866a249.chunk.js",
      "/npm.immutable.4a154ad8eb752929e549.chunk.js",
      "/npm.react-app-polyfill.d83cf03d7d0271d66d4d.chunk.js",
      "/npm.react-redux.1a83e641d97684bf8e93.chunk.js",
      "/npm.react-transition-group.4021eb8a49e80bacb83f.chunk.js",
      "/15.a91f0f466ed629efe9e0.chunk.js",
      "/16.054677e4fd6bf87756df.chunk.js",
      "/17.d99d931a4b505847a86d.chunk.js",
      "/18.bdcce6b94753d8a2bfd8.chunk.js",
      "/19.be120ddac34560895b30.chunk.js",
      "/20.b571a0ee9aa186cbe466.chunk.js",
      "/21.ea94e666cea55cfad6ef.chunk.js",
      "/22.747e791c3cb3d0af95db.chunk.js",
      "/23.8dd16a1edfc2c77edb97.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "322fe6d151d9c14bf33aa3c86cd9d0ffa943f8b1": "/d49c034ff7942ecaabdb3020525b1f7e.jpg",
    "1f2b3796cd2bb4c9aa677f1208551f3edcc7f18d": "/0380f1c2dad138349aaf3999ed7ebbc3.png",
    "1326124a444ee0dbfeec4c9195135168b1c395a8": "/5db5824b5b19760318f568bf51b054a2.png",
    "290536ee5c4a707f14f6889fe0d6e9934b72db71": "/b8e69b9285376214817341b0c7865f37.png",
    "be5b13230f15562f55fffbe88d8c7ee5625f1a81": "/aab95c6bfbf97c9b5cd5ab91379ef07d.png",
    "6b8690e7040626dee0859df4f3849381a434cf53": "/c5f5465af89bb5c4ada576b288e59c05.png",
    "a984aadfb18d1fe4e86358879554ed4e2c982237": "/f278b26b6db2854fc4b867cb5bcba050.png",
    "d28cadb66a8a400dbf9251a9a4fc6d242ce5bfff": "/6ea9aa82fc3835131596509fac77bf5a.png",
    "695020e949300c70d55328bb47dd167d7d23a4b1": "/8dec7022ea74eaad8e1fb0b658dd3047.png",
    "daf1982ce195d306a8d9b6d9245a2900488bb4b6": "/d4764421c2270359a4a9de16fbd18111.png",
    "9de35c4101e326965ba316cb1f1a9b6362fad4e1": "/498dc89b7cccac1624b35953d72fc099.png",
    "7d5e4011ba679faa92d52b573aee78e71929c20f": "/08690ee3a5e27172f13fb2d32c180717.png",
    "0c5447c1762f79d95b46c4eb63960b14d0975f73": "/ed23534bf8393d1400c4bf4d76308230.jpg",
    "9af3782fc37d892816b25c1063016319d8d81146": "/ffdc6dc5c7d052bf229b384662d6d76f.png",
    "1f0239b8eaf43d8ac171eb5f47975d0d70280157": "/b7b3ecb64b6cf9f7a068fd6fd6b6f8af.png",
    "059e190fb52db0bbe001bc736230a64d50c21069": "/73564913de6236214a0d1e4f32c1bd26.jpg",
    "5e53ef208f3fa79a48f8374488f473c76e1233de": "/favicon.ico",
    "da882058347aff3f62e8bc65c2b8b789da384331": "/1c37d17ab4763e2f9c9d9f76f856fa4f.png",
    "c687b4fd8865c6fe0295f1527b7f8ad814952488": "/9d03f51123413552f6296791f90afe73.png",
    "de1b728825be638b78420e08966e64fcf221eb3e": "/2146d266234f33e71c8ad2b007942695.png",
    "b6c47676fdab99a8ee51af1f9b7ddcf2018ed3a9": "/9ac0ec2f24f760d5796b3bac2c2f1f59.png",
    "c73eea6450470d9ab631190b52ffab141eaa1058": "/36d69487d539f38cd97f2d457adf608a.png",
    "5f7e7751dc54c5ef8b092927121dbca73156b970": "/9e856521ccb74baf3a729aba9a1d8083.jpg",
    "66609f9691388e6408a730ae7e07c61abd3b8569": "/759e7c3789dc1116b4e2eb9154be3f1d.png",
    "61a83455139529287b5c704d1c2694c52e09bcee": "/npm.webpack.74f5a4a58a24174e8f47.chunk.js",
    "223e269ca026aae31a4dbed920e692df589feb70": "/npm.lodash.f669a47301d5f23fffaf.chunk.js",
    "5000b00b35d52020e8a157a5ca0683e44f414fea": "/npm.material-ui.718fddd6d6126902d007.chunk.js",
    "6a6ed1a8c94bf7fd06bf65b13cfcbdc01c913355": "/npm.redux-saga.ba4aadbebb4d4d4e9349.chunk.js",
    "509ecd96cded1e009c2c670a4f985ecd81ed600c": "/npm.intl.b21cb7bc6c0cd0d196b0.chunk.js",
    "7914ae5bf1cde8cd7b6f57c15aad3859fd19dad9": "/main.5287e0059022fafb53d0.chunk.js",
    "05c66cf6003afe978789eadf66bc125b583eee55": "/npm.axios.0282152507966a1f7a82.chunk.js",
    "3d0cfda79ffc1990e5095d50665d86f4a46e7f20": "/npm.babel.78a7a1d12b1efa6b4ca1.chunk.js",
    "1780845b495b4f29c381635f1ab26659bb3205a7": "/npm.connected-react-router.935dd82e1f14cac812d7.chunk.js",
    "2ba88e42fe785e6c4e0f44e02b7eb3b8915e413d": "/npm.css-vendor.8e939cc2ba9b8866a249.chunk.js",
    "f37ed81d90ad742e7869893cbc19420d1c70ec33": "/npm.immutable.4a154ad8eb752929e549.chunk.js",
    "2c0e079e87de19e2924267177f7f5de948c9f360": "/npm.react-app-polyfill.d83cf03d7d0271d66d4d.chunk.js",
    "1078f778a4f2867b776a6d21c98bf079dfda2c21": "/npm.react-redux.1a83e641d97684bf8e93.chunk.js",
    "81a47075e87d41ab9f5998377cc28b123bbe6ace": "/npm.react-transition-group.4021eb8a49e80bacb83f.chunk.js",
    "3e5d17db6451a79eba30fb5dd8824efefce52c93": "/runtime.c6c2340d0ffa88711909.js",
    "8756594045eac0febf28253e2cbe86208402f450": "/15.a91f0f466ed629efe9e0.chunk.js",
    "2f6d179e7e1066b56923737d52ef06306371bcc5": "/16.054677e4fd6bf87756df.chunk.js",
    "45d27221b5ff16f7c2f7c9d09fbaed422286fcef": "/17.d99d931a4b505847a86d.chunk.js",
    "1f36c74af2117bd197786dbacc3abbec3b3f7014": "/18.bdcce6b94753d8a2bfd8.chunk.js",
    "99618e300701a7eacec905fbf321cc53bc8c5851": "/19.be120ddac34560895b30.chunk.js",
    "008636fe50887dc3601296f12f248cd377d3360e": "/20.b571a0ee9aa186cbe466.chunk.js",
    "6c3e1bf25085239f56c6fcaaa62bc165c0a6eeac": "/21.ea94e666cea55cfad6ef.chunk.js",
    "bf386db3184440dce2855e288c2d57fb648e12ed": "/22.747e791c3cb3d0af95db.chunk.js",
    "5080ffac384c4f353f3d5fb08d3ecb813c6bd202": "/23.8dd16a1edfc2c77edb97.chunk.js",
    "169f1e298fcaf63d9ee24f9e9a6352c6ca4ba70d": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "5/28/2020, 11:57:21 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });